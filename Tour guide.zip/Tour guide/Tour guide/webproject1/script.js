const inputbox = document.getElementById("input-box");
const listcontainer = document.getElementById("list");

function add_task() {
    if (inputbox.value==="") {
        alert("You must write something before add!");
    }
    else{
        let li = document.createElement("li");
        li.innerHTML=inputbox.value;
        listcontainer.appendChild(li);
        let span = document.createElement("span")
        span.innerHTML="\u00d7"
        li.appendChild(span)
    }
    inputbox.value=""
    saveData()
}
listcontainer.addEventListener("click", function(e){
    if (e.target.tagName == "LI") {
        e.target.classList.toggle("checked")
        saveData()
    }
    else if(e.target.tagName==="SPAN"){
        e.target.parentElement.remove()
        saveData()
    }
},false)

function saveData() {
    localStorage.setItem("data", listcontainer.innerHTML)
}
function showTask() {
    listcontainer.innerHTML = localStorage.getItem("data")
}
showTask()
var visible = true
function hide() {
    if (visible) {
        document.getElementById("hide").style.display="block"
        visible = false
    }
    else{
        document.getElementById("hide").style.display="none"
        visible = true
    }

}

/*exchange*/
function convert_Japan() {
    var mmk = document.getElementById('mmkInput').value;
    var jpyRate = 0.042; // Exchange rate: 1 jpy = 23.8 MMK
    var jpy = mmk * jpyRate;
    document.getElementById('result').innerHTML = mmk + ' MMK = ' + jpy.toFixed(2) + ' JPY';
}
function convert_us() {
    var mmk = document.getElementById('mmkInput2').value;
    var usdRate = 0.00029; // Exchange rate: 3450 MMK = 1 USD (You can adjust this rate accordingly)
    var usd = mmk * usdRate;
    document.getElementById('result2').innerHTML = mmk + ' MMK = ' + usd.toFixed(2) + ' USD';
}
function convert_euro() {
    var mmk = document.getElementById('mmkInput3').value;
    var eurRate = 0.00044; // Exchange rate: 2,277.26 MMK = 1 EUR
    var eur = mmk * eurRate;
    document.getElementById('result3').innerHTML = mmk + ' MMK = ' + eur.toFixed(2) + ' EUR';
}

// var visible1 = true
// function hide_japan() {
//     if (visible1) {
//         document.getElementById("japan").style.display="block"
//         visible1 = false
//     }
//     else{
//         document.getElementById("japan").style.display="none"
//         visible1 = true
//     }

// }
function show_japan(){
    document.getElementById("japan").style.display="block"
    document.getElementById("us").style.display="none"
    document.getElementById("euro").style.display="none"
}

function show_us(){
    document.getElementById("japan").style.display="none"
    document.getElementById("us").style.display="block"
    document.getElementById("euro").style.display="none"
}
function show_euro(){
    document.getElementById("japan").style.display="none"
    document.getElementById("us").style.display="none"
    document.getElementById("euro").style.display="block"
}